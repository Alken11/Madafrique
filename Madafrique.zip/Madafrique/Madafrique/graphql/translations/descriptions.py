class TranslationDescriptions:
    LANGUAGE_CODE = "A language code to return the translation for {type_name}."
    DESCRIPTION = "Returns translated {type_name} fields for the given language code."
