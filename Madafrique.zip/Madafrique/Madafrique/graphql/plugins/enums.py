from ...graphql.core.enums import to_enum
from ...plugins.base_plugin import ConfigurationTypeField

ConfigurationTypeFieldEnum = to_enum(ConfigurationTypeField)
